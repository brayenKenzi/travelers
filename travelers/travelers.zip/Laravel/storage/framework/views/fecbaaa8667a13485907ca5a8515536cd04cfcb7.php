<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Travelers 2020</span>
        </div>
    </div>
</footer>
<!-- End of Footer --><?php /**PATH /media/kenzi/MASTER DATA/classBWA/travelers/travelers/resources/views/includes/admin/footer.blade.php ENDPATH**/ ?>