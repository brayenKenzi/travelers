<?php $__env->startSection('title', 'Checkout Success'); ?>

<?php $__env->startSection('content'); ?>
<main>
    <section class="container section-success text-center">
      <div class="row">
        <div class="col mt-5">
            <img src="<?php echo e(url('frontend/images/ic_mail.png')); ?>">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <h3 class="mt-3">
            Yey! Success
          </h3>
          <p class="mt-1">
            We've sent you email for trip
            <br>
            instruction please read it as well
          </p>
          <a href="<?php echo e(url('/')); ?>" class="btn btn-home-page">
            Home Page
          </a>
        </div>
      </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/kenzi/MASTER DATA/classBWA/travelers/travelers/resources/views/pages/success.blade.php ENDPATH**/ ?>