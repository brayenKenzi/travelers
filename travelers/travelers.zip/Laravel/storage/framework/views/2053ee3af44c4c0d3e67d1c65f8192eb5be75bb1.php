<?php echo e($slot); ?>

<?php /**PATH /media/kenzi/MASTER DATA/classBWA/travelers/travelers/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>